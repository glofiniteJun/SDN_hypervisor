package net.onrc.openvirtex.services.mpls;

/**
 * Created by Administrator on 2016-08-02.
 */

import net.onrc.openvirtex.elements.OVXMap;
import net.onrc.openvirtex.elements.datapath.PhysicalSwitch;
import net.onrc.openvirtex.elements.host.Host;
import net.onrc.openvirtex.elements.network.OVXNetwork;
import net.onrc.openvirtex.exceptions.*;
import net.onrc.openvirtex.messages.OVXMessageUtil;
import net.onrc.openvirtex.protocol.OVXMatch;
import net.onrc.openvirtex.util.BitSetIndex;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.projectfloodlight.openflow.protocol.*;
import org.projectfloodlight.openflow.protocol.action.OFAction;
import org.projectfloodlight.openflow.protocol.action.OFActionPopMpls;
import org.projectfloodlight.openflow.protocol.action.OFActionPushMpls;
import org.projectfloodlight.openflow.protocol.action.OFActionSetField;
import org.projectfloodlight.openflow.protocol.match.Match;
import org.projectfloodlight.openflow.protocol.match.MatchField;
import org.projectfloodlight.openflow.types.EthType;
import org.projectfloodlight.openflow.types.IPv4Address;
import org.projectfloodlight.openflow.types.MacAddress;
import org.projectfloodlight.openflow.types.U32;


import java.util.Collection;
import java.util.LinkedList;
import java.util.List;
import java.util.concurrent.ConcurrentHashMap;

public class MplsManager {
    private static MplsManager instance;

    private static Logger log = LogManager.getLogger(MplsManager.class.getName());

    private static BitSetIndex mplsLabelDistributor = null;

    private static boolean isActive;

    private static OFFactory factory;

    private static ConcurrentHashMap<Integer, ConcurrentHashMap<Integer, MplsLabel>> tenantIdFlowMap;

    private static ConcurrentHashMap<Integer, MplsLabel> flowMplslabelMap;

    private static ConcurrentHashMap<Integer, Integer> originalMatchtoFlowIdMap;

    private static ConcurrentHashMap<Integer, LinkedList<OVXMatch>> flowIdtomodifiedMatchMap;

    public MplsManager() {
        MplsManager.log.info("Starting Mpls Manager");

        mplsLabelDistributor =  new BitSetIndex(BitSetIndex.IndexType.MPLS_ID);
        tenantIdFlowMap = new ConcurrentHashMap<Integer, ConcurrentHashMap<Integer, MplsLabel>>();
        flowMplslabelMap = new ConcurrentHashMap<Integer, MplsLabel>();
        originalMatchtoFlowIdMap =  new ConcurrentHashMap<Integer, Integer>();
        flowIdtomodifiedMatchMap =  new ConcurrentHashMap<Integer, LinkedList<OVXMatch>>();

        factory = OFFactories.getFactory(OFVersion.OF_13);
        isActive = false;
    }

    public synchronized static MplsManager getInstance() {
        if (MplsManager.instance == null) {
            MplsManager.instance = new MplsManager();
        }
        return MplsManager.instance;
    }
    public synchronized void AddMplsActions(List<OFAction> approvedActions, OVXMatch match) {
        //log.info("AddMplsActions");

        if (!isHost(match.getMatch()))
            return;

        MplsLabel label = flowMplslabelMap.get(match.getFlowId());

        if(label == null){
            label = new MplsLabel(makeLabel(match));

            flowMplslabelMap.put(match.getFlowId(), label);
            log.info("Assigned MPLS Label " + label + " for FlowID[" + match.getFlowId() + "]");
        }

        //log.info("Original Match {}", match.getMatch().toString());

        addOriginalMatch(match);

        switch(match.getSwitchType()) {
            case INGRESS: {
                OFActionSetField actionSetMplsLabel = factory.actions().buildSetField()
                        .setField(factory.oxms().mplsLabel(U32.of(label.toInt())))
                        .build();
                approvedActions.add(0, actionSetMplsLabel);

                OFActionPushMpls actionPushMpls = factory.actions().buildPushMpls()
                        .setEthertype(EthType.MPLS_UNICAST)
                        .build();
                approvedActions.add(0, actionPushMpls);

                addOVXMatch(match.getFlowId(), match);
                break;
            }
            case INTERMEDIATE: {
                match.setMatch(
                        OVXMessageUtil.updateMatch(
                                match.getMatch(),
                                match.getMatch().createBuilder()
                                        .setExact(MatchField.ETH_TYPE, EthType.MPLS_UNICAST)
                                        .setExact(MatchField.MPLS_LABEL, U32.of(label.toInt()))
                                        .build())

                );
                addOVXMatch(match.getFlowId(), match);
                break;
            }
            case EGRESS: {
                OFActionPopMpls actionPopMpls = factory.actions().buildPopMpls()
                        .setEthertype(EthType.IPv4)
                        .build();
                approvedActions.add(0, actionPopMpls);

                match.setMatch(
                        OVXMessageUtil.updateMatch(
                                match.getMatch(),
                                match.getMatch().createBuilder()
                                        .setExact(MatchField.ETH_TYPE, EthType.MPLS_UNICAST)
                                        .setExact(MatchField.MPLS_LABEL, U32.of(label.toInt()))
                                        .build())

                );
                addOVXMatch(match.getFlowId(), match);
                break;
            }
        }
        //log.info("Modified Match {}", match.getMatch().toString());

    }


    public int makeLabel(OVXMatch match) {

        MacAddress srcMacAddress = match.getMatch().get(MatchField.ETH_SRC);
        MacAddress dstMacAddress = match.getMatch().get(MatchField.ETH_DST);
        int srcSwitchID = 0, dstSwitchID = 0;

        OVXNetwork vnet = null;
        Collection<Host> hosts = null;
        try {
            vnet = match.getOVXSwitch().getMap().getVirtualNetwork(match.getTenantId());
            hosts = vnet.getHosts();
        } catch (NetworkMappingException e) {
            e.printStackTrace();
        }

        for(Host host : hosts) {
            if (host.getMac().equals(srcMacAddress)) {
                srcSwitchID = host.getPort().getPhysicalPort().getParentSwitch().getSwitchLocID();
                break;
            }
        }

        for(Host host : hosts) {
            if (host.getMac().equals(dstMacAddress)) {
                dstSwitchID = host.getPort().getPhysicalPort().getParentSwitch().getSwitchLocID();
                break;
            }
        }

        return srcSwitchID << 13 | dstSwitchID << 6 | match.getTenantId();
    }


    public void checkIPv4Address(OVXMatch match) {

        MacAddress srcMacAddress = match.getMatch().get(MatchField.ETH_SRC);
        MacAddress dstMacAddress = match.getMatch().get(MatchField.ETH_DST);

        System.out.printf("%s %s\n", srcMacAddress.toString(), dstMacAddress.toString());

        OVXNetwork vnet = null;
        Collection<Host> hosts = null;
        try {
            vnet = match.getOVXSwitch().getMap().getVirtualNetwork(match.getTenantId());
            hosts = vnet.getHosts();
        } catch (NetworkMappingException e) {
            e.printStackTrace();
        }

        IPv4Address srcIP = match.getMatch().get(MatchField.IPV4_SRC);
        if(srcIP == null) {
            for(Host host : hosts) {
                if (host.getMac().equals(srcMacAddress)) {
                    srcIP = IPv4Address.of(host.getIp().getIp());
                    System.out.printf("%s\n", srcIP.toString());
                    break;
                }
            }
        }

        IPv4Address dstIP = match.getMatch().get(MatchField.IPV4_DST);
        if(dstIP == null) {
            for(Host host : hosts) {
                if (host.getMac().equals(dstMacAddress)) {
                    dstIP = IPv4Address.of(host.getIp().getIp());
                    System.out.printf("%s\n", dstIP.toString());
                    break;
                }
            }
        }

        if(match.getMatch().get(MatchField.ETH_TYPE) == null) {
            System.out.printf("match.getMatch().get(MatchField.ETH_TYPE) == null\n");
            match.setMatch(
                    OVXMessageUtil.updateMatch(
                            match.getMatch(),
                            match.getMatch().createBuilder()
                                    //.setExact(MatchField.ETH_TYPE, EthType.IPv4)
                                    .setExact(MatchField.IPV4_SRC, srcIP)
                                    .setExact(MatchField.IPV4_DST, dstIP)
                                    .build()
                    )
            );
        }
    }


    public synchronized Match DeleteMplsActions(OVXMatch match) {
        if (!isActive)
            return null;

        if (!isHost(match.getMatch()))
            return null;

        Integer key = makeMappingKey(match);
        Integer flowId = originalMatchtoFlowIdMap.get(key);

        if(flowId == null) {
            //log.info("No mapping for original Match [" + flowId + "]");
            return null;
        }
        delOriginalMatch(match);

        return delOVXMatch(flowId, match);
    }

    public void addOriginalMatch(OVXMatch match) {

        Integer key = makeMappingKey(match);
        Integer flowId = originalMatchtoFlowIdMap.get(key);

        if(flowId == null) {
            originalMatchtoFlowIdMap.put(key, match.getFlowId());
            log.info("Mapping Original Match [" + key + "] to FlowID[" + match.getFlowId() + "]");
        }
    }

    public void delOriginalMatch(OVXMatch match) {

        Integer key = makeMappingKey(match);
        Integer flowId = originalMatchtoFlowIdMap.get(key);

        if(flowId != null) {
            originalMatchtoFlowIdMap.remove(key);
            log.info("Removing mapping Original Match [" + key + "] to FlowID[" + flowId + "]");
        }
    }


    public void addOVXMatch(Integer flowId, OVXMatch match) {
        LinkedList<OVXMatch> matches = flowIdtomodifiedMatchMap.get(flowId);

        if(matches == null){
            matches = new LinkedList<>();
            matches.add(match);
            flowIdtomodifiedMatchMap.put(flowId, matches);

            log.info("Mapping FlowID[ " + flowId + "] to Modified Match [" + match.getMatch().toString() + "]");
        }else{
            for(OVXMatch ovxMatch : matches) {
                if(ovxMatch.getMatch().equals(match.getMatch())
                        && ovxMatch.getOVXSwitch().getSwitchId() == match.getOVXSwitch().getSwitchId()) {
                    log.debug("Already existing [" + match.getMatch().toString() + "]");
                    return;
                }
            }

            matches.add(match);
            log.info("Mapping FlowID[ " + flowId + "] to Modified Match [" + match.getMatch().toString() + "]");
        }
    }

    public Match delOVXMatch(Integer flowId, OVXMatch match) {
        LinkedList<OVXMatch> matches = flowIdtomodifiedMatchMap.get(flowId);

        if(matches == null) {
            //log.info("No mapping OVXMatches for FlowID [" + flowId + "]");
            return null;
        }

        for(OVXMatch ovxMatch : matches) {
            if(ovxMatch.getOVXSwitch().getSwitchId() == match.getOVXSwitch().getSwitchId()) {
                matches.remove(ovxMatch);

                if(matches.isEmpty()) {
                    flowIdtomodifiedMatchMap.remove(flowId);

                    MplsLabel label = flowMplslabelMap.get(flowId);

                    if(label != null) {
                        flowMplslabelMap.remove(flowId);
                        log.info("Remove flowMplslabelMap [" + flowId + "]");

                        mplsLabelDistributor.releaseMplsLabel(label.toInt());
                        log.info("Release MplsLabel [" + label.toInt() + "]");
                    }
                }
                return ovxMatch.getMatch();
            }
        }

        return null;
    }
    public void setActive(boolean active) {
        isActive = active;
    }

    public boolean isHost(Match match)  {
        if(match.get(MatchField.ETH_SRC) != null) {
            try {
                OVXMap.getInstance().getMAC(match.get(MatchField.ETH_SRC));
            } catch (AddressMappingException e) {
                return false;
            }
        }

        if(match.get(MatchField.ETH_DST) != null) {
            try {
                OVXMap.getInstance().getMAC(match.get(MatchField.ETH_DST));
            } catch (AddressMappingException e) {
                return false;
            }
        }

        return true;
    }

    public Integer makeMappingKey(OVXMatch match) {
        long id = match.getOVXSwitch().getSwitchId();
        final int prime = 283;
        int result = match.getMatch().hashCode();
        result = prime * result + (int)id;

        return result;
    }


    public synchronized void buildPhysicalLSP(PhysicalSwitch psw, int inport, int output, Integer flowId, MplsNodeType type) {
        //log.info(psw.getName() + "[" + type + "][" + inport + ", " + output + "] " + flowId);

        /*LabelSwitchedPath path = flowIdtoLabelSwitchedPathMap.get(flowId);

        if(path == null) {
            log.info("Build LSP for FLOW-ID[" + flowId + "]");
            path = new LabelSwitchedPath(flowId);
            flowIdtoLabelSwitchedPathMap.put(flowId, path);
        }

        switch(type) {
            case MPLS_EGRESS:
                log.info("setEgressNode");
                path.setEgressNode(psw, inport, output);
                break;
            case MPLS_INGRESS:
                log.info("setIngressNode");
                path.setIngressNode(psw, inport, output);
                break;
            case MPLS_INTERMEDIATE:
                log.info("setIntermediateNodes");
                path.setIntermediateNodes(psw, inport, output);
                break;
        }*/
    }
}
