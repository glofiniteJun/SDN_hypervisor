package net.onrc.openvirtex.services.mpls;

/**
 * Created by Administrator on 2016-08-02.
 */
public enum MplsNodeType {
    MPLS_INGRESS,
    MPLS_INTERMEDIATE,
    MPLS_EGRESS
}