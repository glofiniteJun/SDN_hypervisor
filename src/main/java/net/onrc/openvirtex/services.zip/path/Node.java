package net.onrc.openvirtex.services.path;

import net.onrc.openvirtex.elements.datapath.Switch;
import org.projectfloodlight.openflow.protocol.OFFlowMod;

/**
 * Created by bebec on 2017-06-11.
 */
public class Node {
    public Switch sw = null;
    public OFFlowMod flowMod = null;

    public Node(Switch sw, OFFlowMod ofFlowMod) {
        this.sw = sw;
        this.flowMod = ofFlowMod;
    }
}
