package net.onrc.openvirtex.services.path;

import net.onrc.openvirtex.elements.host.Host;

import java.util.LinkedList;
import java.util.List;

/**
 * Created by bebec on 2017-06-11.
 */
public class Path {
    private int flowID;     //vPathID
    private int tenantID;
    private Host srcHost;
    private Host dstHost;
    private Node srcSwitch;
    private Node dstSwitch;
    private Node same;
    private List<Node> intermediate;

    private boolean isBuild;

    public Path(int flowID, int tenantID) {
        this.flowID = flowID;
        this.tenantID = tenantID;
        this.srcSwitch = null;
        this.intermediate = new LinkedList<>();
        this.dstSwitch = null;
        this.same = null;
        this.isBuild = false;
    }

    public void addIntermediate(Node node) {
        this.intermediate.add(node);
    }

    public List<Node> getIntermediate() {
        return this.intermediate;
    }

    public int getFlowID() {
        return this.flowID;
    }

    public int getTenantID() {
        return this.tenantID;
    }

    public void setSrcSwitch(Node srcSwitch) {
        this.srcSwitch = srcSwitch;
    }

    public Node getSrcSwitch() {
        return this.srcSwitch;
    }

    public void setDstSwitch(Node dstSwitch) {
        this.dstSwitch = dstSwitch;
    }

    public Node getDstSwitch() {
        return this.dstSwitch;
    }

    public void setSame(Node same) {
        this.same = same;
    }

    public Node getSame() {
        return this.same;
    }

    public void setSrcHost(Host host) {
        this.srcHost = host;
    }

    public void setDstHost(Host host) {
        this.dstHost = host;
    }

    public Host getSrcHost() {
        return this.srcHost;
    }

    public Host getDstHost() {
        return this.dstHost;
    }

    public void setBuild(boolean isBuild) {
        this.isBuild = isBuild;
    }

    public boolean getBuild() {
        return this.isBuild;
    }
}
