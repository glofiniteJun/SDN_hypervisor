package net.onrc.openvirtex.services.path;

/**
 * Created by bebec on 2017-06-03.
 */
public enum SwitchType {
    INGRESS,
    INTERMEDIATE,
    EGRESS,
    SAME
}


