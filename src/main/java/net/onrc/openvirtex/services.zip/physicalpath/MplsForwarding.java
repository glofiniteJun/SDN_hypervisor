package net.onrc.openvirtex.services.physicalpath;

import net.onrc.openvirtex.elements.OVXMap;
import net.onrc.openvirtex.elements.host.Host;
import net.onrc.openvirtex.elements.network.OVXNetwork;
import net.onrc.openvirtex.exceptions.NetworkMappingException;
import net.onrc.openvirtex.services.path.SwitchType;
import net.onrc.openvirtex.services.virtualpath2.VirtualPath;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.projectfloodlight.openflow.protocol.*;
import org.projectfloodlight.openflow.protocol.action.OFAction;
import org.projectfloodlight.openflow.protocol.action.OFActionPopMpls;
import org.projectfloodlight.openflow.protocol.action.OFActionPushMpls;
import org.projectfloodlight.openflow.protocol.action.OFActionSetField;
import org.projectfloodlight.openflow.protocol.match.Match;
import org.projectfloodlight.openflow.protocol.match.MatchField;
import org.projectfloodlight.openflow.types.EthType;
import org.projectfloodlight.openflow.types.MacAddress;
import org.projectfloodlight.openflow.types.U32;

import java.util.Collection;
import java.util.List;
import java.util.concurrent.ConcurrentHashMap;

/**
 * Created by bebec on 2017-06-07.
 */
public class MplsForwarding {
    private static MplsForwarding instance;

    private static Logger log = LogManager.getLogger(MplsForwarding.class.getName());
    private static OFFactory factory;
    private static ConcurrentHashMap<Integer, MplsLabel> flowMplslabelMap;

    public class MplsLabel {
        private int mplsLabel;
        public MplsLabel(int value) {
            this.mplsLabel = value;
        }

        public int toInt() {
            return this.mplsLabel;
        }
    }

    public MplsForwarding() {
        MplsForwarding.log.info("Starting MplsForwarding");
        this.factory = OFFactories.getFactory(OFVersion.OF_13);
        flowMplslabelMap = new ConcurrentHashMap<Integer, MplsLabel>();
    }

    public synchronized static MplsForwarding getInstance() {
        if (MplsForwarding.instance == null) {
            MplsForwarding.instance = new MplsForwarding();
        }
        return MplsForwarding.instance;
    }

    public OFFlowMod addMplsActions(VirtualPath vPath, OFFlowMod mFlowMod, SwitchType type) {

        MplsLabel label = flowMplslabelMap.get(vPath.getFlowID());

        if(label == null){
            label = new MplsLabel(makeLabel(vPath, mFlowMod));

            flowMplslabelMap.put(vPath.getFlowID(), label);
            log.info("Assigned MPLS Label [" + label.toInt() + "] for FlowID[" + vPath.getFlowID() + "]");
        }

        OFFlowMod ofFlowMod = mFlowMod.createBuilder().build();
        List<OFAction> actions = ofFlowMod.getActions();
        Match match = null;

        //System.out.printf("Before %s\n", ofFlowMod.toString());

        switch(type) {
            case INGRESS:
                OFActionSetField actionSetMplsLabel = factory.actions().buildSetField()
                        .setField(factory.oxms().mplsLabel(U32.of(label.toInt())))
                        .build();
                actions.add(0, actionSetMplsLabel);

                OFActionPushMpls actionPushMpls = factory.actions().buildPushMpls()
                        .setEthertype(EthType.MPLS_UNICAST)
                        .build();
                actions.add(0, actionPushMpls);

                ofFlowMod = ofFlowMod.createBuilder().setActions(actions).build();
                break;
            case INTERMEDIATE:
                match = ofFlowMod.getMatch().createBuilder()
                        .setExact(MatchField.ETH_TYPE, EthType.MPLS_UNICAST)
                        .setExact(MatchField.MPLS_LABEL, U32.of(label.toInt()))
                        .build();

                ofFlowMod = ofFlowMod.createBuilder().setMatch(match).build();
                break;
            case EGRESS:
                OFActionPopMpls actionPopMpls = factory.actions().buildPopMpls()
                        .setEthertype(EthType.IPv4)
                        .build();
                actions.add(0, actionPopMpls);

                match = ofFlowMod.getMatch().createBuilder()
                        .setExact(MatchField.ETH_TYPE, EthType.MPLS_UNICAST)
                        .setExact(MatchField.MPLS_LABEL, U32.of(label.toInt()))
                        .build();

                ofFlowMod = ofFlowMod.createBuilder().setMatch(match).setActions(actions).build();
                break;
            default:
                break;
        }

        //System.out.printf("After %s\n", ofFlowMod.toString());

        return ofFlowMod;
    }

    public int makeLabel(VirtualPath vPath, OFFlowMod flowMod) {
        MacAddress srcMacAddress = flowMod.getMatch().get(MatchField.ETH_SRC);
        MacAddress dstMacAddress = flowMod.getMatch().get(MatchField.ETH_DST);
        int srcSwitchID = 0, dstSwitchID = 0;

        OVXNetwork vnet = null;
        Collection<Host> hosts = null;
        try {
            vnet = OVXMap.getInstance().getVirtualNetwork(vPath.getTenantID());
            hosts = vnet.getHosts();
        } catch (NetworkMappingException e) {
            e.printStackTrace();
        }

        for(Host host : hosts) {
            if (host.getMac().equals(srcMacAddress)) {
                srcSwitchID = host.getPort().getPhysicalPort().getParentSwitch().getSwitchLocID();
                break;
            }
        }

        for(Host host : hosts) {
            if (host.getMac().equals(dstMacAddress)) {
                dstSwitchID = host.getPort().getPhysicalPort().getParentSwitch().getSwitchLocID();
                break;
            }
        }

        return srcSwitchID << 13 | dstSwitchID << 6 | vPath.getTenantID();
    }
}
