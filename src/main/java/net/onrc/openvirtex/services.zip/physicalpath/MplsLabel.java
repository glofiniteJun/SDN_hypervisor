package net.onrc.openvirtex.services.physicalpath;

/**
 * Created by bebec on 2017-06-08.
 */
public class MplsLabel {
}
