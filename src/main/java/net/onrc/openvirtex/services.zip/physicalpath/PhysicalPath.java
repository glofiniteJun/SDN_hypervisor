package net.onrc.openvirtex.services.physicalpath;

import net.onrc.openvirtex.elements.host.Host;
import net.onrc.openvirtex.services.path.SwitchType;
import net.onrc.openvirtex.services.virtualpath.VirtualPath;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.projectfloodlight.openflow.protocol.OFFlowMod;
import org.projectfloodlight.openflow.protocol.OFMessage;

import java.util.HashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;

/**
 * Created by bebec on 2017-06-07.
 */
public class PhysicalPath {

    private static Logger log = LogManager.getLogger(PhysicalPath.class.getName());

    private int flowID;     //vPathID
    private int tenantID;
    private Host ingressHost;
    private Host egressHost;
    private OFFlowMod ingress;
    private OFFlowMod egress;
    private OFFlowMod same;
    private List<OFFlowMod> intermediate;
    private Map<OFFlowMod, OFFlowMod> oFlowModmFlowModMap;

    private boolean isVM;

    public PhysicalPath(int flowID, int tenantID) {
        this.flowID = flowID;
        this.tenantID = tenantID;
        this.ingress = null;
        this.egress = null;
        this.oFlowModmFlowModMap = new HashMap<>();
        this.intermediate = new LinkedList<>();
        this.isVM = false;
    }

    public OFMessage buildPhysicalPath(VirtualPath vPath, OFFlowMod oFlowMod, OFFlowMod mFlowMod, SwitchType type) {

        OFFlowMod ofFlowMod = null;

        //System.out.printf("isBuildPhysicalPath [%s]\n", ofMessage.toString());
        if(vPath.getIngressHost() != null && this.ingressHost == null) {
            this.ingressHost = vPath.getIngressHost();
        }

        if(vPath.getEgressHost() != null && this.egressHost == null) {
            this.egressHost = vPath.getEgressHost();
        }

        switch(type) {
            case INGRESS:
                if(this.ingress == null) {
                    log.debug("this.ingress == null");
                    //ofFlowMod = MplsForwarding.getInstance().addMplsActions(vPath, mFlowMod, type);
                    this.ingress = ofFlowMod.createBuilder().build();
                    this.oFlowModmFlowModMap.put(oFlowMod, ofFlowMod.createBuilder().build());
                }else{
                    log.debug("this.ingress != null");
                    ofFlowMod = this.ingress.createBuilder().build();
                }
                break;
            case INTERMEDIATE:
                if(this.oFlowModmFlowModMap.get(oFlowMod) == null) {
                    log.debug("this.oFlowModmFlowModMap.get(oFlowMod) == null");
                    //ofFlowMod = MplsForwarding.getInstance().addMplsActions(vPath, mFlowMod, type);
                    if (vPath.isBuild()) {
                        this.oFlowModmFlowModMap.put(oFlowMod, ofFlowMod.createBuilder().build());
                        List<OFFlowMod> ofFlowMods = vPath.getIntermediate();
                        for (OFFlowMod flowMod : ofFlowMods) {
                            OFFlowMod modifiedFlowMod = this.oFlowModmFlowModMap.get(flowMod);
                            this.intermediate.add(modifiedFlowMod);
                        }
                    } else {
                        this.oFlowModmFlowModMap.put(oFlowMod, ofFlowMod.createBuilder().build());
                    }
                }else{
                    log.debug("this.oFlowModmFlowModMap.get(oFlowMod) == null");
                    ofFlowMod = this.oFlowModmFlowModMap.get(oFlowMod);
                }
                break;
            case EGRESS:
                if(this.egress == null) {
                    log.debug("this.egress == null");
                    //ofFlowMod = MplsForwarding.getInstance().addMplsActions(vPath, mFlowMod, type);
                    this.egress = ofFlowMod.createBuilder().build();
                    this.oFlowModmFlowModMap.put(oFlowMod, ofFlowMod.createBuilder().build());
                }else{
                    log.debug("this.egress != null");
                    ofFlowMod = this.egress.createBuilder().build();
                }
                break;
            case SAME:
                if(this.same == null) {
                    log.debug("this.same == null");
                    this.same = mFlowMod.createBuilder().build();
                }else{
                    log.debug("this.same != null");
                }
                ofFlowMod =  this.same;
                break;
        }

        return ofFlowMod;
    }

    public OFFlowMod getModifiedFlowMod(OFFlowMod ofFlowMod) {
        return this.oFlowModmFlowModMap.get(ofFlowMod);
    }

    public void setIsVM(boolean isVM) {
        this.isVM = isVM;
    }
}
