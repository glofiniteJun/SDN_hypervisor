package net.onrc.openvirtex.services.physicalpath2;

import net.onrc.openvirtex.elements.datapath.PhysicalSwitch;
import net.onrc.openvirtex.services.path.Node;
import net.onrc.openvirtex.services.path.Path;
import net.onrc.openvirtex.services.path.SwitchType;
import net.onrc.openvirtex.services.physicalpath.MplsForwarding;
import net.onrc.openvirtex.services.virtualpath2.VirtualPath;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.projectfloodlight.openflow.protocol.OFFlowMod;
import org.projectfloodlight.openflow.protocol.OFMessage;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * Created by bebec on 2017-06-11.
 */
public class PhysicalPath extends Path{
    private static Logger log = LogManager.getLogger(PhysicalPath.class.getName());

    private Map<OFFlowMod, Node> oFlowModmFlowModMap;

    public PhysicalPath(int flowID, int tenantID) {
        super(flowID, tenantID);
        this.oFlowModmFlowModMap = new HashMap<>();
    }

    public OFMessage buildPhysicalPath(VirtualPath vPath, OFFlowMod oFlowMod, OFFlowMod mFlowMod, SwitchType type,
                                       PhysicalSwitch psw) {

        OFFlowMod ofFlowMod = null;
        Node node = null;

        //System.out.printf("isBuildPhysicalPath [%s]\n", ofMessage.toString());
        if(vPath.getSrcHost() != null && this.getSrcHost() == null) {
            this.setSrcHost(vPath.getSrcHost());
        }

        if(vPath.getDstHost() != null && this.getDstHost() == null) {
            this.setDstHost(vPath.getDstHost());
        }

        switch(type) {
            case INGRESS:
                if(this.getSrcSwitch() == null) {
                    log.debug("this.ingress == null");
                    ofFlowMod = MplsForwarding.getInstance().addMplsActions(vPath, mFlowMod, type);

                    node = new Node(psw, ofFlowMod);
                    this.setSrcSwitch(node);
                    this.oFlowModmFlowModMap.put(oFlowMod, node);
                }else{
                    log.debug("this.ingress != null");
                    ofFlowMod = this.getSrcSwitch().flowMod.createBuilder().build();
                }
                break;
            case INTERMEDIATE:
                if(this.oFlowModmFlowModMap.get(oFlowMod) == null) {
                    log.debug("this.oFlowModmFlowModMap.get(oFlowMod) == null");
                    ofFlowMod = MplsForwarding.getInstance().addMplsActions(vPath, mFlowMod, type);
                    if (vPath.getBuild()) {
                        this.oFlowModmFlowModMap.put(oFlowMod, new Node(psw, ofFlowMod));
                        List<Node> nodes = vPath.getIntermediate();

                        for (Node n : nodes) {
                            this.getIntermediate().add(n);
                        }
                    } else {
                        this.oFlowModmFlowModMap.put(oFlowMod, new Node(psw, ofFlowMod));
                    }
                }else{
                    log.debug("this.oFlowModmFlowModMap.get(oFlowMod) == null");
                    ofFlowMod = this.oFlowModmFlowModMap.get(oFlowMod).flowMod;
                }
                break;
            case EGRESS:
                if(this.getDstSwitch() == null) {
                    log.debug("this.egress == null");
                    ofFlowMod = MplsForwarding.getInstance().addMplsActions(vPath, mFlowMod, type);

                    node = new Node(psw, ofFlowMod);
                    this.setDstSwitch(node);
                    this.oFlowModmFlowModMap.put(oFlowMod, node);
                }else{
                    log.debug("this.egress != null");
                    ofFlowMod = this.getDstSwitch().flowMod.createBuilder().build();
                }
                break;
            case SAME:
                if(this.getSame() == null) {
                    log.debug("this.same == null");
                    this.setSame(new Node(psw, mFlowMod.createBuilder().build()));
                }else{
                    log.debug("this.same != null");
                }
                ofFlowMod =  this.getSame().flowMod;
                break;
        }

        return ofFlowMod;
    }

    public OFFlowMod getModifiedFlowMod(OFFlowMod ofFlowMod) {
        return this.oFlowModmFlowModMap.get(ofFlowMod).flowMod;
    }
}
