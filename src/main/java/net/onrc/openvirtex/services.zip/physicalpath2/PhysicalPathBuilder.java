package net.onrc.openvirtex.services.physicalpath2;

import net.onrc.openvirtex.elements.datapath.PhysicalSwitch;
import net.onrc.openvirtex.protocol.OVXMatch;
import net.onrc.openvirtex.services.path.SwitchType;
import net.onrc.openvirtex.services.physicalpath2.*;
import net.onrc.openvirtex.services.virtualpath2.VirtualPath;
import net.onrc.openvirtex.services.virtualpath2.VirtualPathBuilder;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.projectfloodlight.openflow.protocol.OFFlowMod;
import org.projectfloodlight.openflow.protocol.OFMessage;

import java.util.concurrent.ConcurrentHashMap;

/**
 * Created by bebec on 2017-06-12.
 */
public class PhysicalPathBuilder {
    private static PhysicalPathBuilder instance;
    private static Logger log = LogManager.getLogger(PhysicalPathBuilder.class.getName());

    private static ConcurrentHashMap<Integer,PhysicalPath> flowIDphysicalPathMap;

    private PhysicalPathBuilder() {


        this.flowIDphysicalPathMap = new ConcurrentHashMap<>();
    }

    public synchronized static PhysicalPathBuilder getInstance() {
        if (PhysicalPathBuilder.instance == null) {
            log.info("Starting PhysicalPathBuilder");

            PhysicalPathBuilder.instance = new PhysicalPathBuilder();
        }
        return PhysicalPathBuilder.instance;
    }

    public synchronized OFMessage buildPhysicalPath(VirtualPath vPath, OFFlowMod oFlowMod, OFFlowMod mFlowMod, SwitchType type,
                                                    PhysicalSwitch psw) {
        PhysicalPath pPath = flowIDphysicalPathMap.get(vPath.getFlowID());
        if(pPath == null){

            pPath = new PhysicalPath(vPath.getFlowID(), vPath.getTenantID());

            flowIDphysicalPathMap.put(vPath.getFlowID(), pPath);
            log.info("PhysicalPath ID [{}]", vPath.getFlowID());
        }

        return pPath.buildPhysicalPath(vPath, oFlowMod, mFlowMod, type, psw);
    }

    public synchronized OFFlowMod removePhysicalPath(OFFlowMod addFlowMod, OVXMatch ovxMatch) {
        PhysicalPath pPath = flowIDphysicalPathMap.get(ovxMatch.getFlowId());

        if(pPath == null){
            log.info("PhysicalPath ID [{}] does not exist", ovxMatch.getFlowId());
            return null;
        }else{
            VirtualPath vPath = VirtualPathBuilder.getInstance().getVirtualPath(ovxMatch.getFlowId());

            if(vPath == null) {
                flowIDphysicalPathMap.remove(ovxMatch.getFlowId());
                log.info("PhysicalPath ID [{}] is removed", ovxMatch.getFlowId());
            }

            return pPath.getModifiedFlowMod(addFlowMod);
        }
    }
}
