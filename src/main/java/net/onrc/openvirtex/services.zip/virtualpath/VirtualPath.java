package net.onrc.openvirtex.services.virtualpath;

import net.onrc.openvirtex.elements.datapath.OVXSwitch;
import net.onrc.openvirtex.elements.datapath.PhysicalSwitch;
import net.onrc.openvirtex.elements.host.Host;
import net.onrc.openvirtex.elements.network.OVXNetwork;
import net.onrc.openvirtex.exceptions.NetworkMappingException;
import net.onrc.openvirtex.protocol.OVXMatch;
import net.onrc.openvirtex.services.path.SwitchType;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.projectfloodlight.openflow.protocol.OFActionType;
import org.projectfloodlight.openflow.protocol.OFFlowMod;
import org.projectfloodlight.openflow.protocol.action.OFAction;
import org.projectfloodlight.openflow.protocol.action.OFActionOutput;
import org.projectfloodlight.openflow.protocol.match.MatchField;
import org.projectfloodlight.openflow.types.IPv4Address;
import org.projectfloodlight.openflow.types.MacAddress;

import java.util.*;

/**
 * Created by bebec on 2017-06-03.
 */
public class VirtualPath {

    private static Logger log = LogManager.getLogger(VirtualPath.class.getName());

    private int flowID;     //vPathID
    private int tenantID;
    private Host ingressHost;
    private Host egressHost;
    private OFFlowMod ingress;
    private OFFlowMod egress;
    private OFFlowMod same;
    private List<OFFlowMod> intermediate;
    private Map<OFFlowMod, OVXSwitch> flowModOVXSwitchMap;
    private Map<OVXSwitch, OFFlowMod> ovxSwitchFlowModMap;


    private boolean isBuild;
    private boolean isRemoved;

    private int outport = -1;

    public class PhysicalSwitchOutport {
        public int outport;
        public OFFlowMod ofFlowMod;
        public PhysicalSwitchOutport(int outport, OFFlowMod ofFlowMod) {
            this.outport = outport;
            this.ofFlowMod = ofFlowMod;
        }
    }

    public VirtualPath(int flowID, int tenantID) {
        this.flowID = flowID;
        this.tenantID = tenantID;
        this.isBuild = false;
        this.ingress = null;
        this.egress = null;
        this.flowModOVXSwitchMap = new HashMap<>();
        this.ovxSwitchFlowModMap = new HashMap<>();
        this.intermediate = new LinkedList<>();
        this.isBuild = false;
        this.isRemoved = false;
    }

    public boolean isBuild() {
        return this.isBuild;
    }

    public synchronized void buildVirtualPath(SwitchType type, OFFlowMod oriFlowMod, OVXSwitch ovxSwitch) {
        if(this.isBuild == true) {
            //this.log.info("FlowID [{}] is already built", this.flowID);
            return;
        }

        setHosts(type, oriFlowMod, ovxSwitch);
        switch(type) {
            case INGRESS:
                if(this.ingress == null) {
                    this.ingress = oriFlowMod;
                    this.flowModOVXSwitchMap.put(oriFlowMod, ovxSwitch);
                    this.ovxSwitchFlowModMap.put(ovxSwitch, oriFlowMod);

                    this.log.debug("INGRESS is set for FlowID {}", this.flowID);
                }
                break;
            case INTERMEDIATE:
                if(this.intermediate.contains(oriFlowMod)) {
                    this.log.debug("oriFlowMod {}is contained", oriFlowMod.toString());
                }else{
                    this.intermediate.add(oriFlowMod);
                    this.flowModOVXSwitchMap.put(oriFlowMod, ovxSwitch);
                    this.ovxSwitchFlowModMap.put(ovxSwitch, oriFlowMod);

                    this.log.debug("INTERMEDIATE is set for FlowID {}", this.flowID);
                }
                break;
            case EGRESS:
                if(this.egress == null) {
                    this.egress = oriFlowMod;
                    this.flowModOVXSwitchMap.put(oriFlowMod, ovxSwitch);
                    this.ovxSwitchFlowModMap.put(ovxSwitch, oriFlowMod);

                    this.log.debug("EGRESS is set for FlowID {}", this.flowID);
                }
                break;
            case SAME:
                if(this.same == null) {
                    this.same = oriFlowMod;
                    this.flowModOVXSwitchMap.put(oriFlowMod, ovxSwitch);
                    this.ovxSwitchFlowModMap.put(ovxSwitch, oriFlowMod);
                }
                break;
        }

        if(!this.isBuild)
            this.isBuild = isBuildVirtualPath();
    }

    public OFFlowMod removeVirtualPath(OFFlowMod delFlowMod, OVXMatch ovxMatch) {
        OVXSwitch sw = ovxMatch.getOVXSwitch();
        OFFlowMod ofFlowMod = this.ovxSwitchFlowModMap.get(sw);

        if(ofFlowMod.getMatch().equals(delFlowMod.getMatch()) && ofFlowMod.getCookie().equals(delFlowMod.getCookie())) {
            this.ovxSwitchFlowModMap.remove(sw);
            this.flowModOVXSwitchMap.remove(ofFlowMod);

            if(this.ingress != null && this.ingress.equals(ofFlowMod)) {
                this.ingress = null;
                ovxMatch.setSwitchType(SwitchType.INGRESS);
            }else if(this.intermediate.size() != 0 && this.intermediate.contains(ofFlowMod)) {
                this.intermediate.remove(ofFlowMod);
                ovxMatch.setSwitchType(SwitchType.INTERMEDIATE);
            }else if(this.egress != null && this.egress.equals(ofFlowMod)) {
                this.egress = null;
                ovxMatch.setSwitchType(SwitchType.EGRESS);
            }else if(this.same != null && this.same.equals(ofFlowMod)) {
                this.same = null;
                ovxMatch.setSwitchType(SwitchType.SAME);
            }
            return ofFlowMod;
        }else{
            log.debug("Match is not matching {}/{}", delFlowMod.getMatch().toString(),
                    ofFlowMod.getMatch().toString());
            return null;
        }
    }

    public synchronized boolean isRemoveVirtualPath() {
        if(this.egress != null) {
            this.isRemoved = false;
            return this.isRemoved;
        }

        if(this.ingress != null) {
            this.isRemoved = false;
            return this.isRemoved;
        }

        if(this.intermediate.size() != 0) {
            this.isRemoved = false;
            return this.isRemoved;
        }

        if(this.same != null) {
            this.isRemoved = false;
            return this.isRemoved;
        }

        this.isRemoved = true;
        return this.isRemoved;
    }

    public boolean isRemoved() {
        return this.isRemoved;
    }


    public synchronized boolean isBuildVirtualPath() {
        if(same == null) {
            if(ingressHost == null || egressHost == null || ingress == null || egress == null) {
                return false;
            }
        }else{
            if(ingressHost == null || egressHost == null) {
                return false;
            }else{
                return true;
            }
        }

        log.debug("Checking VirtualPath ID [{}]", this.flowID);

        int inport = ingressHost.getPort().getPortNumber();

        //log.info("Ingress FlowMod {}", ingress.toString());

        if(inport == this.ingress.getMatch().get(MatchField.IN_PORT).getShortPortNumber()) {
            List<OFAction> actions = this.ingress.getActions();
            for(OFAction action : actions) {
                if(action.getType() == OFActionType.OUTPUT) {
                    outport = ((OFActionOutput)action).getPort().getShortPortNumber();
                    break;
                }
            }
        }

        if(outport == -1) {
            log.info("Wrong FlowMod {}", this.ingress.toString());
            return false;
        }

        OVXSwitch ingressOvxSwitch = this.flowModOVXSwitchMap.get(this.ingress);
        PhysicalSwitch pSwitch = ingressOvxSwitch.getPort((short)outport)
                .getPhysicalPort().getLink().getOutLink().getDstSwitch();
        //System.out.printf("ingressOvxSwitch %s\n", pSwitch.toString());

        OVXSwitch egressOvxSwitch = this.flowModOVXSwitchMap.get(this.egress);
        PhysicalSwitch pSwitch2 = egressOvxSwitch
                .getPort(this.egress.getMatch().get(MatchField.IN_PORT).getShortPortNumber())
                .getPhysicalPort().getParentSwitch();
        //System.out.printf("egressOvxSwitch %s\n", pSwitch2.toString());

        if(pSwitch.equals(pSwitch2)) {
            //log.info("pSwitch == pSwitch2");
            List<OFAction> actions = this.egress.getActions();
            for(OFAction action : actions) {
                if(action.getType() == OFActionType.OUTPUT) {
                    outport = ((OFActionOutput)action).getPort().getShortPortNumber();

                    if(outport == egressHost.getPort().getPortNumber()) {
                        log.info("FlowID {} VirtualPath is built", this.flowID);
                        return true;
                    }
                }
            }
            log.debug("Wrong FlowMod {", this.egressHost.toString());
        }else{
            //log.info("pSwitch != pSwitch2");
            //log.info("find next intermediate switch of ingress switch ");
            List<OFFlowMod> sortedFlowMods = new LinkedList<>();
            List<OFFlowMod> clonedFlowMods = new LinkedList<>();
            clonedFlowMods.addAll(this.intermediate);

            if(this.intermediate.size() == 0)
                return false;

            while(sortedFlowMods.size() != this.intermediate.size()) {

                log.debug("Target pSwitch {}", pSwitch.toString());

                PhysicalSwitchOutport switchOutport = checkNextSwitch(pSwitch, clonedFlowMods);

                if (switchOutport != null) {
                    sortedFlowMods.add(switchOutport.ofFlowMod);
                    clonedFlowMods.remove(switchOutport.ofFlowMod);

                    log.debug("Found pSwitch {}", pSwitch.toString());

                    OVXSwitch ovxSwitch = this.flowModOVXSwitchMap.get(switchOutport.ofFlowMod);
                    pSwitch = ovxSwitch.getPort((short)outport).getPhysicalPort().getLink().getOutLink().getDstSwitch();    //next PhysicalSwitch
                }else{
                    //log.info("Next FlowMod is not");
                    return false;
                }
            }

            if(pSwitch.equals(pSwitch2)) {
                //log.info("Egress FlowMod {}", egress.toString());

                List<OFAction> actions = this.egress.getActions();
                for(OFAction action : actions) {
                    if(action.getType() == OFActionType.OUTPUT) {
                        outport = ((OFActionOutput)action).getPort().getShortPortNumber();

                        if(outport == egressHost.getPort().getPortNumber()) {
                            log.info("VirtualPath ID [{}] is built", this.flowID);
                            return true;
                        }else{
                            return false;
                        }
                    }
                }
            }
        }

        outport = -1;
        return false;
    }

    public PhysicalSwitchOutport checkNextSwitch(PhysicalSwitch pSwitch, List<OFFlowMod> flowMods) {
        for(OFFlowMod ofFlowMod : flowMods) {

            OVXSwitch ovxSwitch = this.flowModOVXSwitchMap.get(ofFlowMod);
            PhysicalSwitch tempSwitch = ovxSwitch.getPort(ofFlowMod.getMatch().get(MatchField.IN_PORT).getShortPortNumber())
                    .getPhysicalPort().getParentSwitch();

            if (tempSwitch.equals(pSwitch)) {
                return new PhysicalSwitchOutport(outport, ofFlowMod);
            }
        }
        return null;
    }

    public void setHosts(SwitchType type, OFFlowMod oriFlowMod, OVXSwitch ovxSwitch) {
        if(this.ingressHost != null && this.egressHost != null )
            return;

        OVXNetwork vnet = null;
        Collection<Host> hosts = null;
        try {
            vnet = ovxSwitch.getMap().getVirtualNetwork(this.tenantID);
            hosts = vnet.getHosts();
        } catch (NetworkMappingException e) {
            e.printStackTrace();
        }

        if(this.ingressHost == null) {
            MacAddress srcMacAddress = oriFlowMod.getMatch().get(MatchField.ETH_SRC);
            for(Host host : hosts) {
                if (host.getMac().equals(srcMacAddress)) {
                    if(type == SwitchType.INGRESS) {
                        this.ingressHost = host;
                        log.info("Ingress Host is set {} {}", host.getMac(), IPv4Address.of(host.getIp().getIp()));
                    }
                    break;
                }
            }
        }

        if(this.egressHost == null) {
            MacAddress dstMacAddress = oriFlowMod.getMatch().get(MatchField.ETH_DST);
            for(Host host : hosts) {
                if (host.getMac().equals(dstMacAddress)) {
                    if(type == SwitchType.EGRESS) {
                        this.egressHost = host;
                        log.info("Egress Host is set {} {}", host.getMac(), IPv4Address.of(host.getIp().getIp()));
                    }
                    break;
                }
            }
        }
    }


    public int getFlowID() {
        return this.flowID;
    }

    public int getTenantID() {
        return this.tenantID;
    }

    public OFFlowMod getIngress() {
        return this.ingress;
    }

    public OFFlowMod getEgress() {
        return this.egress;
    }

    public List<OFFlowMod> getIntermediate() {
        return this.intermediate;
    }

    public Host getIngressHost() {
        return ingressHost;
    }

    public Host getEgressHost() {
        return egressHost;
    }
}
