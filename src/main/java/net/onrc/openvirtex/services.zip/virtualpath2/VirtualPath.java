package net.onrc.openvirtex.services.virtualpath2;

import net.onrc.openvirtex.elements.datapath.OVXSwitch;
import net.onrc.openvirtex.elements.datapath.PhysicalSwitch;
import net.onrc.openvirtex.elements.host.Host;
import net.onrc.openvirtex.elements.network.OVXNetwork;
import net.onrc.openvirtex.exceptions.NetworkMappingException;
import net.onrc.openvirtex.protocol.OVXMatch;
import net.onrc.openvirtex.services.path.Node;
import net.onrc.openvirtex.services.path.Path;
import net.onrc.openvirtex.services.path.SwitchType;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.projectfloodlight.openflow.protocol.OFActionType;
import org.projectfloodlight.openflow.protocol.OFFlowMod;
import org.projectfloodlight.openflow.protocol.action.OFAction;
import org.projectfloodlight.openflow.protocol.action.OFActionOutput;
import org.projectfloodlight.openflow.protocol.match.MatchField;
import org.projectfloodlight.openflow.types.IPv4Address;
import org.projectfloodlight.openflow.types.MacAddress;

import java.util.*;

/**
 * Created by bebec on 2017-06-11.
 */
public class VirtualPath extends Path{
    private static Logger log = LogManager.getLogger(VirtualPath.class.getName());

    private Map<OFFlowMod, OVXSwitch> flowModOVXSwitchMap;
    private Map<OVXSwitch, OFFlowMod> ovxSwitchFlowModMap;

    private boolean isRemoved;
    private int outport = -1;

    public VirtualPath(int flowID, int tenantID) {
        super(flowID, tenantID);
        this.flowModOVXSwitchMap = new HashMap<>();
        this.ovxSwitchFlowModMap = new HashMap<>();
        this.isRemoved = false;
    }

    public class PhysicalSwitchOutport {
        public int outport;
        public Node node;
        public PhysicalSwitchOutport(int outport, Node node) {
            this.outport = outport;
            this.node = node;
        }
    }

    public synchronized void buildVirtualPath(SwitchType type, OFFlowMod oriFlowMod, OVXSwitch ovxSwitch) {

        if(this.getBuild() == true) {
            //this.log.info("FlowID [{}] is already built", this.flowID);
            return;
        }

        Node node = new Node(ovxSwitch, oriFlowMod);

        setHosts(type, oriFlowMod, ovxSwitch);
        switch(type) {
            case INGRESS:
                if(this.getSrcSwitch() == null) {
                    this.setSrcSwitch(node);
                    this.flowModOVXSwitchMap.put(oriFlowMod, ovxSwitch);
                    this.ovxSwitchFlowModMap.put(ovxSwitch, oriFlowMod);

                    this.log.debug("INGRESS is set for FlowID {}", this.getFlowID());
                }
                break;
            case INTERMEDIATE:
                if(this.getIntermediate().contains(oriFlowMod)) {
                    this.log.debug("oriFlowMod {}is contained", oriFlowMod.toString());
                }else{
                    this.addIntermediate(node);
                    this.flowModOVXSwitchMap.put(oriFlowMod, ovxSwitch);
                    this.ovxSwitchFlowModMap.put(ovxSwitch, oriFlowMod);

                    this.log.debug("INTERMEDIATE is set for FlowID {}", this.getFlowID());
                }
                break;
            case EGRESS:
                if(this.getDstSwitch() == null) {
                    this.setDstSwitch(node);
                    this.flowModOVXSwitchMap.put(oriFlowMod, ovxSwitch);
                    this.ovxSwitchFlowModMap.put(ovxSwitch, oriFlowMod);

                    this.log.debug("EGRESS is set for FlowID {}", this.getFlowID());
                }
                break;
            case SAME:
                if(this.getSame() == null) {
                    this.setSame(node);
                    this.flowModOVXSwitchMap.put(oriFlowMod, ovxSwitch);
                    this.ovxSwitchFlowModMap.put(ovxSwitch, oriFlowMod);
                }
                break;
        }

        if(!this.getBuild())
            this.setBuild(isBuildVirtualPath());
    }

    public void setHosts(SwitchType type, OFFlowMod oriFlowMod, OVXSwitch ovxSwitch) {
        if(this.getSrcHost() != null && this.getDstHost() != null )
            return;

        OVXNetwork vnet = null;
        Collection<Host> hosts = null;
        try {
            vnet = ovxSwitch.getMap().getVirtualNetwork(this.getTenantID());
            hosts = vnet.getHosts();
        } catch (NetworkMappingException e) {
            e.printStackTrace();
        }

        if(this.getSrcHost() == null) {
            MacAddress srcMacAddress = oriFlowMod.getMatch().get(MatchField.ETH_SRC);
            for(Host host : hosts) {
                if (host.getMac().equals(srcMacAddress)) {
                    if(type == SwitchType.INGRESS) {
                        this.setSrcHost(host);
                        log.info("Ingress Host is set {} {}", host.getMac(), IPv4Address.of(host.getIp().getIp()));
                    }
                    break;
                }
            }
        }

        if(this.getDstHost() == null) {
            MacAddress dstMacAddress = oriFlowMod.getMatch().get(MatchField.ETH_DST);
            for(Host host : hosts) {
                if (host.getMac().equals(dstMacAddress)) {
                    if(type == SwitchType.EGRESS) {
                        this.setDstHost(host);
                        log.info("Egress Host is set {} {}", host.getMac(), IPv4Address.of(host.getIp().getIp()));
                    }
                    break;
                }
            }
        }
    }

    public synchronized boolean isBuildVirtualPath() {
        if(this.getSame() == null) {
            if(this.getSrcHost() == null || this.getDstHost() == null ||
                    this.getSrcSwitch() == null || this.getDstSwitch() == null) {
                return false;
            }
        }else{
            if(this.getSrcHost() == null || this.getDstHost() == null) {
                return false;
            }else{
                return true;
            }
        }

        log.debug("Checking VirtualPath ID [{}]", this.getFlowID());

        int inport = this.getSrcHost().getPort().getPortNumber();

        //log.info("Ingress FlowMod {}", ingress.toString());

        if(inport == this.getSrcSwitch().flowMod.getMatch().get(MatchField.IN_PORT).getShortPortNumber()) {
            List<OFAction> actions = this.getSrcSwitch().flowMod.getActions();
            for(OFAction action : actions) {
                if(action.getType() == OFActionType.OUTPUT) {
                    outport = ((OFActionOutput)action).getPort().getShortPortNumber();
                    break;
                }
            }
        }

        if(outport == -1) {
            log.info("Wrong FlowMod {}", this.getSrcSwitch().flowMod.toString());
            return false;
        }

        OVXSwitch ingressOvxSwitch = this.flowModOVXSwitchMap.get(this.getSrcSwitch().flowMod);
        PhysicalSwitch pSwitch = ingressOvxSwitch.getPort((short)outport)
                .getPhysicalPort().getLink().getOutLink().getDstSwitch();
        //System.out.printf("ingressOvxSwitch %s\n", pSwitch.toString());

        OVXSwitch egressOvxSwitch = this.flowModOVXSwitchMap.get(this.getDstSwitch().flowMod);
        PhysicalSwitch pSwitch2 = egressOvxSwitch
                .getPort(this.getDstSwitch().flowMod.getMatch().get(MatchField.IN_PORT).getShortPortNumber())
                .getPhysicalPort().getParentSwitch();
        //System.out.printf("egressOvxSwitch %s\n", pSwitch2.toString());

        if(pSwitch.equals(pSwitch2)) {
            //log.info("pSwitch == pSwitch2");
            List<OFAction> actions = this.getDstSwitch().flowMod.getActions();
            for(OFAction action : actions) {
                if(action.getType() == OFActionType.OUTPUT) {
                    outport = ((OFActionOutput)action).getPort().getShortPortNumber();

                    if(outport == this.getDstHost().getPort().getPortNumber()) {
                        log.info("FlowID {} VirtualPath is built", this.getFlowID());
                        return true;
                    }
                }
            }
            log.debug("Wrong FlowMod {", this.getDstHost().toString());
        }else{
            //log.info("pSwitch != pSwitch2");
            //log.info("find next intermediate switch of ingress switch ");
            List<Node> sortedFlowMods = new LinkedList<>();
            List<Node> clonedFlowMods = new LinkedList<>();
            clonedFlowMods.addAll(this.getIntermediate());

            if(this.getIntermediate().size() == 0)
                return false;

            while(sortedFlowMods.size() != this.getIntermediate().size()) {

                log.debug("Target pSwitch {}", pSwitch.toString());

                PhysicalSwitchOutport switchOutport = checkNextSwitch(pSwitch, clonedFlowMods);

                if (switchOutport != null) {
                    sortedFlowMods.add(switchOutport.node);
                    clonedFlowMods.remove(switchOutport.node);

                    log.debug("Found pSwitch {}", pSwitch.toString());

                    OVXSwitch ovxSwitch = this.flowModOVXSwitchMap.get(switchOutport.node.flowMod);
                    pSwitch = ovxSwitch.getPort((short)outport).getPhysicalPort().getLink().getOutLink().getDstSwitch();    //next PhysicalSwitch
                }else{
                    //log.info("Next FlowMod is not");
                    return false;
                }
            }

            if(pSwitch.equals(pSwitch2)) {
                //log.info("Egress FlowMod {}", egress.toString());

                List<OFAction> actions = this.getDstSwitch().flowMod.getActions();
                for(OFAction action : actions) {
                    if(action.getType() == OFActionType.OUTPUT) {
                        outport = ((OFActionOutput)action).getPort().getShortPortNumber();

                        if(outport == this.getDstHost().getPort().getPortNumber()) {
                            log.info("VirtualPath ID [{}] is built", this.getFlowID());
                            return true;
                        }else{
                            return false;
                        }
                    }
                }
            }
        }

        outport = -1;
        return false;
    }

    public PhysicalSwitchOutport checkNextSwitch(PhysicalSwitch pSwitch, List<Node> flowMods) {
        for(Node node : flowMods) {
            OVXSwitch ovxSwitch = this.flowModOVXSwitchMap.get(node.flowMod);
            PhysicalSwitch tempSwitch = ovxSwitch.getPort(node.flowMod.getMatch().get(MatchField.IN_PORT).getShortPortNumber())
                    .getPhysicalPort().getParentSwitch();

            if (tempSwitch.equals(pSwitch)) {
                return new PhysicalSwitchOutport(outport, node);
            }
        }
        return null;
    }

    public OFFlowMod removeVirtualPath(OFFlowMod delFlowMod, OVXMatch ovxMatch) {
        OVXSwitch sw = ovxMatch.getOVXSwitch();
        OFFlowMod ofFlowMod = this.ovxSwitchFlowModMap.get(sw);

        if(ofFlowMod.getMatch().equals(delFlowMod.getMatch()) && ofFlowMod.getCookie().equals(delFlowMod.getCookie())) {
            this.ovxSwitchFlowModMap.remove(sw);
            this.flowModOVXSwitchMap.remove(ofFlowMod);

            if(this.getSrcSwitch() != null && this.getSrcSwitch().flowMod.equals(ofFlowMod)) {
                this.setSrcSwitch(null);
                ovxMatch.setSwitchType(SwitchType.INGRESS);
            }else if(this.getIntermediate().size() != 0 && this.getIntermediate().contains(ofFlowMod)) {
                this.getIntermediate().remove(ofFlowMod);
                ovxMatch.setSwitchType(SwitchType.INTERMEDIATE);
            }else if(this.getDstSwitch() != null && this.getDstSwitch().flowMod.equals(ofFlowMod)) {
                this.setDstSwitch(null);
                ovxMatch.setSwitchType(SwitchType.EGRESS);
            }else if(this.getSame() != null && this.getSame().flowMod.equals(ofFlowMod)) {
                this.setSame(null);
                ovxMatch.setSwitchType(SwitchType.SAME);
            }
            return ofFlowMod;
        }else{
            log.debug("Match is not matching {}/{}", delFlowMod.getMatch().toString(),
                    ofFlowMod.getMatch().toString());
            return null;
        }
    }

    public synchronized boolean isRemoveVirtualPath() {
        if(this.getDstSwitch() != null) {
            this.isRemoved = false;
            return this.isRemoved;
        }

        if(this.getSrcSwitch() != null) {
            this.isRemoved = false;
            return this.isRemoved;
        }

        if(this.getIntermediate().size() != 0) {
            this.isRemoved = false;
            return this.isRemoved;
        }

        if(this.getSame() != null) {
            this.isRemoved = false;
            return this.isRemoved;
        }

        this.isRemoved = true;
        return this.isRemoved;
    }
}
