package net.onrc.openvirtex.services.virtualpath2;

import net.onrc.openvirtex.elements.network.OVXNetwork;
import net.onrc.openvirtex.exceptions.IndexOutOfBoundException;
import net.onrc.openvirtex.exceptions.NetworkMappingException;
import net.onrc.openvirtex.protocol.OVXMatch;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.projectfloodlight.openflow.protocol.OFFlowMod;
import org.projectfloodlight.openflow.protocol.match.MatchField;

import java.util.concurrent.ConcurrentHashMap;

/**
 * Created by bebec on 2017-06-11.
 */
public class VirtualPathBuilder {
    private static VirtualPathBuilder instance;
    private static Logger log = LogManager.getLogger(VirtualPathBuilder.class.getName());

    private static ConcurrentHashMap<Integer, VirtualPath> flowIDvirtualPathMap;

    private VirtualPathBuilder() {


        this.flowIDvirtualPathMap = new ConcurrentHashMap<>();
    }

    public synchronized static VirtualPathBuilder getInstance() {
        if (VirtualPathBuilder.instance == null) {
            log.info("Starting VirtualPathBuilder");

            VirtualPathBuilder.instance = new VirtualPathBuilder();
        }
        return VirtualPathBuilder.instance;
    }

    //only for 1:1 = OVXSwitch:PhysicalSwitch Mapping. Additional implementation is required 1:N Mapping
    public synchronized VirtualPath buildVirtualPath(OVXMatch ovxMatch, OFFlowMod oriFlowMod) {
        VirtualPath vPath = flowIDvirtualPathMap.get(ovxMatch.getFlowId());
        if(vPath == null){
            vPath = new VirtualPath(ovxMatch.getFlowId(), ovxMatch.getTenantId());

            flowIDvirtualPathMap.put(ovxMatch.getFlowId(), vPath);
            log.info("Start building VirtualPath ID [{}]", ovxMatch.getFlowId());
        }

        if(vPath.getBuild()) {
            log.info("VirtualPath ID [{}] is built", ovxMatch.getFlowId());
        }else{
            //log.info("VirtualPath ID [{}] is not built", ovxMatch.getFlowId());
            vPath.buildVirtualPath(ovxMatch.getSwitchType(), oriFlowMod, ovxMatch.getOVXSwitch());
        }

        return vPath;
    }

    public synchronized OFFlowMod removeVirtualPath(OFFlowMod delFlowMod, OVXMatch ovxMatch) {
        OVXNetwork vnet = null;
        Integer flowId = 0;
        try {
            ovxMatch.setTenantId(ovxMatch.getOVXSwitch().getTenantId());
            vnet = ovxMatch.getOVXSwitch().getMap().getVirtualNetwork(ovxMatch.getTenantId());
        } catch (NetworkMappingException e) {
            e.printStackTrace();
        }

        try {
            flowId =  vnet.getFlowManager().storeFlowValues(
                    delFlowMod.getMatch().get(MatchField.ETH_SRC).getBytes(),
                    delFlowMod.getMatch().get(MatchField.ETH_DST).getBytes());

            ovxMatch.setFlowId(flowId);
        } catch (IndexOutOfBoundException e) {
            e.printStackTrace();
        }

        VirtualPath vPath = flowIDvirtualPathMap.get(flowId);
        if(vPath == null){
            log.info("VirtualPath ID [{}] does not exist", flowId);
            return null;
        }else{
            OFFlowMod ofFlowMod = vPath.removeVirtualPath(delFlowMod, ovxMatch);
            if(vPath.isRemoveVirtualPath()) {
                flowIDvirtualPathMap.remove(flowId);
                log.info("VirtualPath ID [{}] is removed", flowId);
            }
            return ofFlowMod;
        }
    }

    public VirtualPath getVirtualPath(int flowId) {
        return this.flowIDvirtualPathMap.get(flowId);
    }

    public void removeVirtualPath(int flowId) {
        VirtualPath vPath = this.flowIDvirtualPathMap.get(flowId);
        if(vPath.isRemoveVirtualPath())
            flowIDvirtualPathMap.remove(flowId);
    }
}
