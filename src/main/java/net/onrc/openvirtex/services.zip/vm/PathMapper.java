package net.onrc.openvirtex.services.vm;

/**
 * Created by bebec on 2017-06-08.
 */
public class PathMapper {
}
